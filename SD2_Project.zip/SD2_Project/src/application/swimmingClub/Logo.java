package application.swimmingClub;

import java.awt.Font;
import java.awt.*;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

public class Logo {
    public void generateLogo() {
        int width = 180;
        int height = 25;
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics g = image.getGraphics();
        g.setFont(new Font("SansSerif", Font.BOLD, 14));
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.drawString("SWIMMING CLUB", 10, 20);

        for (int y = 0; y < height; y++) {
            StringBuilder builder = new StringBuilder();

            for (int x = 0; x < width; x++) {
                builder.append(image.getRGB(x, y) == -16777216 ? "-" : "@");
            }
            makeColors(builder);
            System.out.println(builder);
        }
    }

    private static void makeColors(StringBuilder text) {
        for (int i = 0; i < text.length(); i++) {
            switch (text.charAt(i)) {
                case '@':
                    // BLACK blocks
                    text.replace(i, i + 1, "\u001B[44m \u001b[0m");
                    break;
            }
        }
    }
}