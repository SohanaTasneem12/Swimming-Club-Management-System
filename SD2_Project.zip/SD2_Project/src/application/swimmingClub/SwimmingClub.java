package application.swimmingClub;

import application.swimmingClub.staff.Manager;
import application.swimmingClub.staff.Trainer;
import application.swimmingClub.staff.Staff;
import application.swimmingClub.staff.Treasurer;
import application.swimmingClub.database.FileHandler;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

// main class of the application responsible with logging in the user of the system. Adding default members
public class SwimmingClub {

    public static List<Member> memberList = new ArrayList<Member>();

    // disciplines in the form of an array of strings
    public static final String[] DISCIPLINES = {"None", "Backstroke", "Freestyle", "Butterfly"};

    //Staff memebrs
    private Staff manager  = new Manager(memberList);
    private Staff trainer     = new Trainer(memberList);
    private Staff treasurer = new Treasurer(memberList);

    private Login login = new Login(manager, trainer, treasurer);


    public SwimmingClub()
    {
        //add default members; used for debugging
        memberList.add(new Member("Sadia", "Chowdhury", 19 , "sadia9@gmail.com"      , "active" , "elite"   , SwimmingClub.DISCIPLINES[3], getRandLapTime()));
        memberList.add(new Member("Rima", "Akter", 98, "rima876@yahoo.com"    , "active" , "elite"   , SwimmingClub.DISCIPLINES[2], getRandLapTime()));
        memberList.add(new Member("Sadia",  "Naj", 37, "sadianaj22@hotmail.com"   , "passive", "exercise", SwimmingClub.DISCIPLINES[0], getRandLapTime()));
        memberList.add(new Member("Sumaiya", "Azad" , 21, "sumu77@gmail.com"    , "active" , "elite"   , SwimmingClub.DISCIPLINES[1], getRandLapTime()));
        memberList.add(new Member("Lamisa", "Mashiat", 67, "lamisa6@gmail.com"     , "active" , "elite"   , SwimmingClub.DISCIPLINES[2], getRandLapTime()));
        memberList.add(new Member("Sadia", "Rahman", 37, "sadia123@yahoo.com"   , "passive", "exercise", SwimmingClub.DISCIPLINES[0], getRandLapTime()));
        memberList.add(new Member("Ziana", "Mehnaz", 13, "ziana05@outlook.com"  , "active" , "elite"   , SwimmingClub.DISCIPLINES[1], getRandLapTime()));
        memberList.add(new Member("Samiha", "Siddique", 54, "samix@gmail.com"      , "active" , "elite"   , SwimmingClub.DISCIPLINES[1], getRandLapTime()));
        memberList.add(new Member("Nabila", "Tasnif", 26, "tasnif23@gmail.com"       , "passive", "exercise", SwimmingClub.DISCIPLINES[0], getRandLapTime()));
        memberList.add(new Member("Tahia", "Parsa", 35, "tahia777@hotmail.com", "passive", "exercise", SwimmingClub.DISCIPLINES[0], getRandLapTime()));
        memberList.add(new Member("Tahsina", "Kamal", 30, "tashina30@gmail.com"    , "passive", "exercise", SwimmingClub.DISCIPLINES[0], getRandLapTime()));

        //save the members to the file
        FileHandler.writeToFile(memberList);
    }

    //open the login menu
    public void run () {

        login.login();
    }

    // return a random value for the member's best lap
    public static double getRandLapTime()
    {
        //random double between 100 and 500
        return 100.0 + new Random().nextDouble() * 400.0;
    }
}
