package application.swimmingClub;

import application.swimmingClub.staff.Staff;

import static application.swimmingClub.staff.Staff.*;

/*
    Handles login credentials
 */
public class Login {
    private Staff manager;
    private Staff trainer;
    private Staff treasurer;
    private Logo logo;
    Login(Staff manager, Staff trainer,Staff treasurer) {
        this.manager = manager;
        this.trainer = trainer;
        this.treasurer = treasurer;
        this.logo = new Logo(); // Create an instance of the Logo class
    }
    void login() {
        // Generate and display the logo
        logo.generateLogo();
        while(true) {

            //print the menu and runs a case based on user input (1-4)
            switch (Staff.chooseMenuOptions(RESET +
                    "\n┌───────────────────── " + CYAN + "Welcome to Swimming Club!" + RESET + " ─────────────────────┐\n" +
                    "│\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t  │\n" +
                    "│ " + YELLOW + "1. Manager" + RESET + "\t\t\t\t\t\t\t\t\t\t\t\t\t\t  │\n" +
                    "│ " + PURPLE + "2. Treasurer" + RESET + "\t\t\t\t\t\t\t\t\t\t\t\t\t\t  │\n" +
                    "│ " + BLUE + "3. Trainer" + RESET + "\t\t\t\t\t\t\t\t\t\t\t\t\t\t  │\n" +
                    "│ " + RED + "4. [Exit]" + RESET + "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t  │" + "\n│\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t  │\n" +
                    "└────────────────────── " + CYAN + "Choose an option: " + DARK_GREEN + "[1-4]" + RESET + " ──────────────────────┘\n\n",1, 5)) {
                case 1://user chose the Manager option
                    //ask for the username and the password of the Manager
                    if (loginCheck(manager.getUsername(), manager.getPassword())) {
                        System.out.println(YELLOW + "\nLogged in as Manager!\n" + RESET);
                        //enter the main menu of the chairman
                        manager.menu();
                    } else {
                        System.out.println(RED + "Invalid input!" + RESET);
                        //"press enter to continue" prompt
                        Staff.advance();
                    }
                    break;
                case 2://user chose the Treasurer option
                    if (loginCheck(treasurer.getUsername(), treasurer.getPassword())) {
                        System.out.println(PURPLE + "\nLogged in as Treasurer!\n" + RESET);
                        treasurer.menu();
                    } else {
                        System.out.println(RED + "Invalid input!" + RESET);
                        Staff.advance();
                    }
                    break;
                case 3://user chose the Trainer option
                    if (loginCheck(trainer.getUsername(), trainer.getPassword())) {
                        System.out.println(BLUE + "\nLogged in as Trainer!\n" + RESET);
                        trainer.menu();
                    } else {
                        System.out.println(RED + "Invalid input!" + RESET);
                        Staff.advance();
                    }
                    break;
                case 4://User chose to exit the program
                    System.out.println(RED + "The program is closing..." + RESET);
                    System.exit(0);
            }
        }
    }

    //checks if the username and password entered by the user matches the ones provided by parameters
    private static boolean loginCheck(String defaultUsername, String defaultPassword)
    {
        System.out.println("\n------------ " + CYAN + "Log in!" + RESET + " ------------\n");
        System.out.print(GREEN + "Username " + BLUE + "[Default:" + GREEN + "\'" + defaultUsername + "\'" + BLUE + "]" + GREEN + ": " + RESET);
        String username = Staff.getInputString();
        System.out.print(GREEN + "Password " + BLUE + "[Default:" + GREEN + "\'" + defaultPassword + "\'" + BLUE + "]" + GREEN + ": " + RESET);
        String password = Staff.getInputString();

        return username.equals(defaultUsername) &&
                password.equals(defaultPassword);
    }
}
