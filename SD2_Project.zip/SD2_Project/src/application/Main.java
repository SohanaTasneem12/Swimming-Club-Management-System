package application;
import application.swimmingClub.SwimmingClub;
// This class runs an instance of SwimmingClub.
public class Main {

    public static void main(String[] args) {

        SwimmingClub swimmingClub = new SwimmingClub();

        swimmingClub.run();

    }
}
